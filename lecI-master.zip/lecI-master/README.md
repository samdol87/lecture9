# lecI
Support files for Lecture I, (507 lecture 8, 206, lecture 9
